import React from "react";
import{
    GoogleMap,
    useLoadScript,
    Marker,
    InfoWindow,
}from "@react-google-maps/api";
import { formatRelative} from "date-fns";

import "@reach/combobox/styles.css";

export default function App(){
    return <div>map</div>;
}
