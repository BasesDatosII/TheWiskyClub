import React from "react";

//version 1.0

import Home from './Home'
import MapAPI from "./MapAPI";


export function App(){
    return (<div>
        <MapAPI></MapAPI>
    </div>);
}